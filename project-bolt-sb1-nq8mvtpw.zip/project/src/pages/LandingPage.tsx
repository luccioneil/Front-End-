import React from 'react';
import { Link } from 'react-router-dom';
import { LineChart, TrendingUp, Users, BarChart2 } from 'lucide-react';

const LandingPage = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
          Make Smarter Investment Decisions
        </h1>
        <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
          Advanced stock analysis tools powered by real-time data and machine learning to help you stay ahead in the market.
        </p>
        <Link
          to="/search"
          className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
        >
          Start Analyzing Stocks
          <TrendingUp className="ml-2 h-5 w-5" />
        </Link>
      </div>

      {/* Features Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <LineChart className="h-12 w-12 text-blue-600 mb-4" />
          <h3 className="text-lg font-semibold mb-2">Real-Time Analysis</h3>
          <p className="text-gray-600">Get instant access to live market data and comprehensive stock analysis.</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <BarChart2 className="h-12 w-12 text-blue-600 mb-4" />
          <h3 className="text-lg font-semibold mb-2">Advanced Charts</h3>
          <p className="text-gray-600">Visualize market trends with our interactive charting tools.</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <Users className="h-12 w-12 text-blue-600 mb-4" />
          <h3 className="text-lg font-semibold mb-2">Expert Insights</h3>
          <p className="text-gray-600">Access curated insights from financial experts and analysts.</p>
        </div>
      </div>

      {/* Testimonials Section */}
      <div className="bg-white rounded-lg shadow-sm p-8 mb-16">
        <h2 className="text-2xl font-bold text-center mb-8">What Our Users Say</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="text-center">
            <img
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
              alt="User avatar"
              className="w-16 h-16 rounded-full mx-auto mb-4"
            />
            <p className="text-gray-600 italic mb-4">"This platform has transformed how I analyze stocks. The real-time insights are invaluable."</p>
            <p className="font-semibold">John D.</p>
            <p className="text-sm text-gray-500">Investment Analyst</p>
          </div>
          <div className="text-center">
            <img
              src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
              alt="User avatar"
              className="w-16 h-16 rounded-full mx-auto mb-4"
            />
            <p className="text-gray-600 italic mb-4">"The most comprehensive stock analysis tool I've used. Perfect for both beginners and pros."</p>
            <p className="font-semibold">Sarah M.</p>
            <p className="text-sm text-gray-500">Portfolio Manager</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;