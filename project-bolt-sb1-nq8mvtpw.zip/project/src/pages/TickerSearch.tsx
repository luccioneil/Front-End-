import React, { useState } from 'react';
import { Search } from 'lucide-react';

const popularStocks = [
  { symbol: 'AAPL', name: 'Apple Inc.' },
  { symbol: 'MSFT', name: 'Microsoft Corporation' },
  { symbol: 'GOOGL', name: 'Alphabet Inc.' },
  { symbol: 'AMZN', name: 'Amazon.com Inc.' },
];

const TickerSearch = () => {
  const [ticker, setTicker] = useState('');
  const [suggestions, setSuggestions] = useState<string[]>([]);

  const handleTickerChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.toUpperCase();
    setTicker(value);
    
    // Simple mock autocomplete
    if (value) {
      const filtered = popularStocks
        .filter(stock => stock.symbol.includes(value))
        .map(stock => stock.symbol);
      setSuggestions(filtered);
    } else {
      setSuggestions([]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Searching for ticker:', ticker);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Search Stock Symbols</h1>
        <p className="text-gray-600">Enter a stock symbol (e.g., AAPL for Apple Inc.)</p>
      </div>

      <form onSubmit={handleSubmit} className="mb-8">
        <div className="relative">
          <input
            type="text"
            value={ticker}
            onChange={handleTickerChange}
            placeholder="Enter stock symbol..."
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
          <button
            type="submit"
            className="absolute right-2 top-2 p-2 text-blue-600 hover:text-blue-700"
          >
            <Search className="h-6 w-6" />
          </button>
        </div>
        
        {suggestions.length > 0 && (
          <div className="mt-2 bg-white border border-gray-200 rounded-lg shadow-sm">
            {suggestions.map((suggestion) => (
              <button
                key={suggestion}
                onClick={() => setTicker(suggestion)}
                className="block w-full text-left px-4 py-2 hover:bg-gray-50"
              >
                {suggestion}
              </button>
            ))}
          </div>
        )}
      </form>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-lg font-semibold mb-4">Popular Stocks</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {popularStocks.map((stock) => (
            <button
              key={stock.symbol}
              onClick={() => setTicker(stock.symbol)}
              className="p-4 border border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors"
            >
              <p className="font-semibold text-blue-600">{stock.symbol}</p>
              <p className="text-sm text-gray-600">{stock.name}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TickerSearch;